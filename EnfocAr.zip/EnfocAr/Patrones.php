<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>EnfocAr</title>
    <link rel="stylesheet" href="styles.css" />
</head>

<script>
    fetch("mostrar_puntos_usuario.php")
        .then(res => res.json())
        .then(data => {
            document.getElementById("puntosUsuario").textContent =
                "Puntos: " + data.puntos;
        });
</script>

<body>

    <div class="encabezado">
        <img src="EnfocAr_logo.png" alt="EnfocAr" class="logo">
    </div>

    <h1>Patrones</h1>

    <div class="menu">
        <div id="contenedor">
            <h3 id="estado">Haga click en "Iniciar"</h3>
            <button class="botones" onclick="iniciarJuego()">Iniciar</button>
            <br>
            <button class="patrn" style="font-size: 10vh;" data-num="1">A</button>
            <button class="patrn" style="font-size: 10vh;" data-num="2">B</button>
            <button class="patrn" style="font-size: 10vh;" data-num="3">C</button>
            <button class="patrn" style="font-size: 10vh;" data-num="4">D</button>
            <button class="patrn" style="font-size: 10vh;" data-num="5">E</button>
            <button class="patrn" style="font-size: 10vh;" data-num="6">F</button>
            <br>
            <h2 id="Puntaje">Puntaje: 0</h2>
        </div>
        <div id="end-game-container" class="end-game-container" style="text-align: center;"></div>
    </div>

    <script src="patron.js"></script>
    <br>
    <a href="index.php"><button class="botones">Menú</button></a>

</body>
<div class="puntosUsuario" id="puntosUsuario">Puntos: 0</div>
</html>