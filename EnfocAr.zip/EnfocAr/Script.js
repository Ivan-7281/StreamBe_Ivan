// JavaScript source code
const piezas = document.querySelectorAll('.pieza');
const rotaciones = {};
const volteos = {};
let piezaActiva = null;
let offsetX = 0;
let offsetY = 0;

piezas.forEach(pieza => {
    rotaciones[pieza.id] = 0;
    volteos[pieza.id] = 1;

    // Arrastre
    pieza.addEventListener('mousedown', (e) => {
        piezaActiva = pieza;
        offsetX = e.clientX - pieza.offsetLeft;
        offsetY = e.clientY - pieza.offsetTop;
        pieza.style.cursor = 'grabbing';
    });

    // Rotaci�n con clic derecho
    pieza.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        rotaciones[pieza.id] = (rotaciones[pieza.id] + 90) % 360;
        actualizarTransformacion(pieza);
    });
});

document.addEventListener('mouseup', () => {
    if (piezaActiva) piezaActiva.style.cursor = 'grab';
    piezaActiva = null;
});

document.addEventListener('mousemove', (e) => {
    if (piezaActiva) {
        piezaActiva.style.left = (e.clientX - offsetX) + 'px';
        piezaActiva.style.top = (e.clientY - offsetY) + 'px';
    }
});

// Volteo con tecla "V"
document.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 'v' && piezaActiva) {
        volteos[piezaActiva.id] *= -1;
        actualizarTransformacion(piezaActiva);
    }
});

function actualizarTransformacion(pieza) {
    const id = pieza.id;
    pieza.style.transform = `rotate(${rotaciones[id]}deg) scaleX(${volteos[id]})`;
}