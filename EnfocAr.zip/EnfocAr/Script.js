// JavaScript source code
let arrastrando = false;

document.addEventListener('mousedown', function () {
    arrastrando = true;
});

document.addEventListener('mouseup', function () {
    arrastrando = false;
});

document.addEventListener('mousemove', function (event) {
    if (arrastrando) {
        const imagen = document.querySelector('.pieza');
        imagen.style.left = event.clientX + 'px';
        imagen.style.top = event.clientY + 'px';
    }
});