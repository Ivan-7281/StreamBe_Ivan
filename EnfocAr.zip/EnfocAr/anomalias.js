let puntos = 0;

const puntaje = document.getElementById('Puntaje');

function iniciarJuego() {
    const inicio = document.getElementById("inicio");
    inicio.style.display = "none";
    const carga = document.getElementById("carga");
    carga.textContent = "Cargando...";
    imagen.src = "";

    setTimeout(() => {
        const aux = Math.floor(Math.random() * 11) + 1;
        let imagenSrc = "";

        if (aux === 1 || aux === 2) {
            imagenSrc = "imagenes/mostrador_base.png";
        } else if (aux === 3 || aux === 4) {
            imagenSrc = "imagenes/mostrador_alt1.png";
        } else if (aux === 5 || aux === 6) {
            imagenSrc = "imagenes/mostrador_alt2.png";
        } else if (aux === 7 || aux === 8) {
            imagenSrc = "imagenes/mostrador_alt3.png";
        } else if (aux === 9 || aux === 10) {
            imagenSrc = "imagenes/mostrador_alt4.png";
        } else {
            imagenSrc = "imagenes/mostrador_alt5.png";
        }

        carga.textContent = "";
        document.getElementById("imagen").src = imagenSrc;
        const botonera = document.getElementById('botonera');
        botonera.innerHTML = `
        <h2>Diagnostico:</h2>
        <button class="botones" onclick='diagnosticarIgual()'>Misma imagen</button>
        <button class="botones" onclick='diagnosticarDistinto()'>Distinta imagen</button>
        `;
    }, 2000);
}

function diagnosticarIgual() {
    if (imagen.src.endsWith("mostrador_base.png")) {
        puntos++;
        puntaje.textContent = `Puntaje: ${puntos}`;
        iniciarJuego();
    } else {
        const mainContainer = document.getElementById('contenedor');
        if (mainContainer) {
            mainContainer.remove();
        }

        const endGameContainer = document.getElementById('end-game-container');
        endGameContainer.innerHTML = `
        <h1>Diagn�stico equivocado</h1>
        <h2>Puntaje: ${puntos}</h2>
        <button class="botones" onclick='location.reload()'>Volver a empezar</button>
        `;
    }
}

function diagnosticarDistinto() {
    if (imagen.src.endsWith("mostrador_base.png")) {
        const mainContainer = document.getElementById('contenedor');
        if (mainContainer) {
            mainContainer.remove();
        }

        const endGameContainer = document.getElementById('end-game-container');
        endGameContainer.innerHTML = `
        <h1>Diagn�stico equivocado</h1>
        <h2>Puntaje: ${puntos}</h2>
        <button class="botones" onclick='location.reload()'>Volver a empezar</button>
        `;
    } else {
        puntos++;
        puntaje.textContent = `Puntaje: ${puntos}`;
        iniciarJuego();
    }
}
