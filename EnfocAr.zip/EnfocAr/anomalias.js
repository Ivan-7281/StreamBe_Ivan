let puntos = 0;
const puntaje = document.getElementById('Puntaje');
const imagen = document.getElementById("imagen");

function iniciarJuego() {
    const inicio = document.getElementById("inicio");
    inicio.style.display = "none";
    const carga = document.getElementById("carga");
    carga.textContent = "Cargando...";
    imagen.src = "";

    setTimeout(() => {
        const aux = Math.floor(Math.random() * 11) + 1;
        let imagenSrc = "";

        if (aux === 1 || aux === 2) {
            imagenSrc = "mostrador_base.png";
        } else if (aux === 3 || aux === 4) {
            imagenSrc = "mostrador_alt1.png";
        } else if (aux === 5 || aux === 6) {
            imagenSrc = "mostrador_alt2.png";
        } else if (aux === 7 || aux === 8) {
            imagenSrc = "mostrador_alt3.png";
        } else if (aux === 9 || aux === 10) {
            imagenSrc = "mostrador_alt4.png";
        } else {
            imagenSrc = "mostrador_alt5.png";
        }

        carga.textContent = "";
        imagen.src = imagenSrc;
        const botonera = document.getElementById('botonera');
        botonera.innerHTML = `
        <h2>Diagnóstico:</h2>
        <button class="botones" onclick='diagnosticarIgual()'>Misma imagen</button>
        <button class="botones" onclick='diagnosticarDistinto()'>Distinta imagen</button>
        `;
    }, 2000);
}

function diagnosticarIgual() {
    if (imagen.src.endsWith("mostrador_base.png")) {
        puntos++;
        puntaje.textContent = `Puntaje: ${puntos}`;
        iniciarJuego();
    } else {
        terminarJuego();
    }
}

function diagnosticarDistinto() {
    if (imagen.src.endsWith("mostrador_base.png")) {
        terminarJuego();
    } else {
        puntos++;
        puntaje.textContent = `Puntaje: ${puntos}`;
        iniciarJuego();
    }
}

function terminarJuego() {
    const mainContainer = document.getElementById('contenedor');
    if (mainContainer) {
        mainContainer.remove();
    }

    const endGameContainer = document.getElementById('end-game-container');

    // Enviar puntaje al servidor
    fetch("guardar_puntaje.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ puntaje: puntos }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Error al guardar puntaje");
        }
        return response.text();
    })
    .then(data => {
        console.log(data);
        endGameContainer.innerHTML = `
            <h1>Diagnóstico equivocado</h1>
            <h2>Puntaje final: ${puntos}</h2>
            <button class="botones" onclick="window.location.href='mostrar_puntajes.php'">
                Ver puntajes
            </button>
            <br><br>
            <button class="botones" onclick='location.reload()'>Volver a empezar</button>
        `;
        // ✅ Reiniciar puntos solo después de guardar correctamente
        puntos = 0;
    })
    .catch(error => {
        console.error("Error al guardar:", error);
        endGameContainer.innerHTML = `
            <h1>Diagnóstico equivocado</h1>
            <h2>Puntaje final: ${puntos}</h2>
            <p style="color:red;">Error al guardar el puntaje.</p>
            <button class="botones" onclick="window.location.href='mostrar_puntajes.php'">
                Ver puntajes
            </button>
            <br><br>
            <button class="botones" onclick='location.reload()'>Volver a empezar</button>
        `;
    });
}