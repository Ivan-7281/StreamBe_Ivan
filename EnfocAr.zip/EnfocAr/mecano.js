const words = [
    'bariloche',
    'plataforma5',
    'luna',
    'sunset',
    'flea',
    'aeroplano',
    'papeles',
    'unlimited',
    'argentum',
    'amor',
    'getaway',
    'estadio',
    'cuartel',
    'moonbow',
    'ballester',
    'zephyrina',
    'dafunk',
    'chile',
    'myasishchev',
    'pulqui',
    'identidad'
];
function randomWords() {
    const index = Math.floor(Math.random() * words.length);
    return words[index];
}

console.log(randomWords());

let palabraAleatoria = '';
let time = 10;
let score = 0;

function addToDOM() {
    palabraAleatoria = randomWords();
    const h1 = document.getElementById('randomWord');
    h1.textContent = palabraAleatoria;
}

addToDOM();

const inputTexto = document.getElementById('text');

inputTexto.addEventListener('input', function (e) {
    console.log('Texto ingresado:', e.target.value);
});

inputTexto.addEventListener('input', function (e) {
    let palabraIngresada = e.target.value;

    if (palabraIngresada === palabraAleatoria) {
        time += 3;
        inputTexto.value = '';
        addToDOM();
        updateScore();
    }
});
const timeSpan = document.getElementById('timeSpan');

function actualizarTiempo() {
    time--;
    timeSpan.textContent = `${time}s`;

    if (time === 0) {
        clearInterval(intervaloTiempo);
        gameOver();

        const mainContainer = document.querySelector('.main');
        if (mainContainer) {
            mainContainer.remove();
        }
    }
}

const intervaloTiempo = setInterval(actualizarTiempo, 1000);
const scoreElement = document.getElementById('score');

function updateScore() {
    score++;
    scoreElement.textContent = score;
}
function gameOver() {
    const endGameContainer = document.getElementById('end-game-container');

    endGameContainer.innerHTML = `
    <h1>�Se acab� el tiempo!</h1>
    <p>Tu puntuaci�n final fue: ${score}</p>
    <button onclick='location.reload()'>Volv� a empezar</button>
  `;
}
