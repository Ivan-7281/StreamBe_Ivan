<?php
session_start();
include 'db.php';

// Consulta para sumar los puntajes totales de cada usuario
$sql = "SELECT u.usuario, SUM(p.puntaje) AS total_puntos
        FROM puntajes p
        JOIN usuarios u ON p.usuario_id = u.id
        GROUP BY u.usuario
        ORDER BY total_puntos DESC";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>🏆 Puntajes Totales - EnfocAr</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="encabezado">
        <img src="EnfocAr_logo.png" alt="EnfocAr" class="logo">
    </div>
    <div id= "menuPrincipal">
        <div class= "submenu">
            <h1>🏆 Tabla de puntajes totales</h1>
            
            <table border="1" style="border-collapse: collapse; margin:auto; text-align:center;">
                <tr>
                    <th>Posición</th>
                    <th>Usuario</th>
                    <th>Puntos Totales</th>
                </tr>
                <?php
                $posicion = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$posicion}</td>
                            <td>{$row['usuario']}</td>
                            <td>{$row['total_puntos']}</td>
                          </tr>";
                    $posicion++;
                }
                ?>
            </table>
            <br>
            <a href="index.php"><button class="botones">Menú</button></a>
        </div>
    </div>

</body>
</html>