let puntos = 0;

const puntaje = document.getElementById('Puntaje');
const botones = document.querySelectorAll('.inferior');

botones.forEach(boton => {
    while (true) {
        boton.style.backgroundColor = 'rgb(0, 128, 255)';
        setTimeout(() => {
            boton.style.backgroundColor = 'rgb(128, 255, 0)';
        }, 250);
        
    }
    boton.addEventListener('click', () => {
        boton.style.backgroundColor = 'rgb(0, 128, 255)';
        setTimeout(() => {
            boton.style.backgroundColor = 'rgb(128, 255, 0)';
        }, 250);
        boton.style.backgroundColor = 'rgb(255, 64, 128)';
        setTimeout(() => {
            boton.style.backgroundColor = 'rgb(255, 192, 0)';
        }, 250);
    });
});