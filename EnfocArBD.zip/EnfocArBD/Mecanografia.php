﻿<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>EnfocAr</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<script>
    fetch("mostrar_puntos_usuario.php")
        .then(res => res.json())
        .then(data => {
            document.getElementById("puntosUsuario").textContent =
                "Puntos: " + data.puntos;
        });
</script>
<body>

    <div class="encabezado">
        <h1>Proyecto "EnfocAr"</h1>
    </div>

    <div class="menu">
        <div class="main">
            <h1>Mecanografía</h1>
            <p>Escribí la siguiente palabra:</p>
            <h1 id="randomWord"></h1>
            <input type="text" id="text" autocomplete="off" placeholder="Type the word here..." />
            <p class="time-container">
                Tiempo restante: <span id="timeSpan">10s</span>
            </p>
            <p class="score-container">Score: <span id="score">0</span></p>
        </div>
        <div id="end-game-container" class="end-game-container"></div>
    </div>
    <script src="mecano.js"></script>
    <a href="index.php"><button class="botones">Menú</button></a>

</body>
<div class="puntosUsuario" id="puntosUsuario">Puntos: 0</div>
</html>