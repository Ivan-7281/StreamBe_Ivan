<?php
session_start();
include "db.php";

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo "No hay usuario logueado";
    exit;
}

// Obtener y decodificar el JSON del body
$data = json_decode(file_get_contents("php://input"), true);

// Validar que el puntaje haya llegado
if (!isset($data['puntaje'])) {
    http_response_code(400);
    echo "Falta el puntaje";
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$puntaje = intval($data['puntaje']);

// Guardar en la base de datos
$sql = "INSERT INTO puntajes (usuario_id, puntaje) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $usuario_id, $puntaje);

if ($stmt->execute()) {
    echo "Puntaje guardado correctamente";
} else {
    http_response_code(500);
    echo "Error al guardar puntaje: " . $conn->error;
}

$stmt->close();
$conn->close();
?>