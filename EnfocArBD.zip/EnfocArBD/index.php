﻿<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>EnfocAr</title>
    <link rel="stylesheet" href="styles.css" />
</head>


<body>

    <div class="encabezado">
        <img src="EnfocAr_logo.png" alt="EnfocAr" class="logo">
        <?php if (isset($_SESSION['usuario'])): ?>
            <a href="logout.php"><button class="botones">Cerrar sesión</button></a>
            <a href="mostrar_puntajes.php"><button class="botones">Ver puntajes</button></a>
        <?php endif; ?>
    </div>

    <div id= "menuPrincipal">
        <?php if (isset($_SESSION['usuario'])): ?>
            <p>Bienvenido, <strong><?php echo htmlspecialchars($_SESSION['usuario']); ?></strong></p>
            <div class="submenu">
                <p class="descripcion">Este es un espacio para entrenar la inteligencia espacial.  Usted podrá armar figuras utilizando las piezas otorgadas.  No hay objetivos a alcanzar, puntos, ni forma de perder.</p>
                <a href="Pentomino.html"><button class="botonPrimario">Pentominó</button></a>
            </div>
            <div class="submenu">
                <p class="descripcion">Usted va a tener que escribir en el campo de texto la palabra indicada arriba del mismo antes de que se acabe el tiempo.  Cada palabra bien escrita va a sumarle 1 punto y 3 segundos.  Si el tiempo se le acaba, pierde.</p>
                <a href="Mecanografia.php"><button class="botonPrimario">Mecanografía</button></a>
            </div>
            <div class="submenu">
                <p class="descripcion">Obrerve la imagen original con atención, luego de la pantalla de carga observe la imagen que aparecerá.  Usted debe decir si la segunda imagen es la misma u otra parecida basándose únicamente en su memoria.  Cada diagnóstico correcto va a sumarle un punto.  Si el diagnóstico es erróneo, pierde.</p>
                <a href="anomalias.php"><button class="botonPrimario">Encontrar diferencias</button></a>
            </div>
            <div class="submenu">
                <p class="descripcion">Los 6 botones van a iluminarse aleatoriamente.  Usted deberá replicar el patrón de los botones.  Cada respuesta correcta va a sumarle 1 punto y un nivel de dificultad.  Si repite de forma incorrecta el patrón, pierde.</p>
                <a href="Patrones.php"><button class="botonPrimario">Patrones</button></a>
            </div>
            <div class="submenu">
                <h3>Fuera de servicio</h3>
                <p class="descripcion">[En Desarrollo]</p>
                <a href="reflejos.html"><button class="botonPrimario">Recordar palabras</button></a>
            </div>
            
        <?php else: ?>
            <h2>Bienvenido a EnfocAr</h2>
            <p>Por favor, iniciá sesión o registrate para jugar.</p>
            <a href="login.php"><button class="botonPrimario">Iniciar sesión</button></a>
            <a href="registro.php"><button class="botonPrimario">Registrarse</button></a>
        <?php endif; ?>
    </div>
    
</body>
</html>