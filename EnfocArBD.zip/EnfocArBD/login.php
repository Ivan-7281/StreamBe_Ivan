<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];

    $sql = "SELECT * FROM usuarios WHERE usuario='$usuario'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($contrasena, $row['contrasena'])) {
            $_SESSION['usuario_id'] = $row['id'];
            $_SESSION['usuario'] = $row['usuario'];
            header("Location: index.php");
            exit;
        } else {
            echo "<script>alert('Contraseña incorrecta');</script>";
        }
    } else {
        echo "<script>alert('Usuario no encontrado');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar sesión - EnfocAr</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
    <div class="encabezado">
        <img src="EnfocAr_logo.png" alt="EnfocAr" class="logo">
    </div>
    <div id= "menuPrincipal">
        <div class= "submenu">
            <h2>Iniciar sesión</h2>
            <form method="POST">
                <label>Usuario:</label><br>
                <input type="text" name="usuario" required><br><br>
                <label>Contraseña:</label><br>
                <input type="password" name="contrasena" required><br><br>
                <button class="botones">Entrar</button>
            </form>
            <a href="registro.php">Crear cuenta nueva</a>
        </div>
    </div>
</body>
</html>