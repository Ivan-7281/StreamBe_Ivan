const words = [
    'bariloche','plataforma5','luna','sunset','flea','aeroplano','papeles','unlimited',
    'argentum','amor','getaway','estadio','cuartel','moonbow','ballester','zephyrina',
    'dafunk','chile','myasishchev','pulqui','identidad'
];

function randomWords() {
    return words[Math.floor(Math.random() * words.length)];
}

let palabraAleatoria = '';
let time = 10;
let score = 0;

function addToDOM() {
    palabraAleatoria = randomWords();
    document.getElementById('randomWord').textContent = palabraAleatoria;
}

addToDOM();

const inputTexto = document.getElementById('text');
inputTexto.addEventListener('input', function (e) {
    if (e.target.value === palabraAleatoria) {
        time += 3;
        inputTexto.value = '';
        addToDOM();
        updateScore();
    }
});

const timeSpan = document.getElementById('timeSpan');
const scoreElement = document.getElementById('score');

function actualizarTiempo() {
    time--;
    timeSpan.textContent = `${time}s`;

    if (time === 0) {
        clearInterval(intervaloTiempo);
        gameOver();
        const mainElement = document.querySelector('.main');
if (mainElement) {
    mainElement.remove();
}
    }
}
const intervaloTiempo = setInterval(actualizarTiempo, 1000);

function updateScore() {
    score++;
    scoreElement.textContent = score;
}

function gameOver() {
    const endGameContainer = document.getElementById('end-game-container');

    // Enviar el puntaje al servidor
    fetch("guardar_puntaje.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ puntaje: score }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Error al guardar puntaje");
        }
        // Mostrar botón para ver puntajes
        endGameContainer.innerHTML = `
            <h1>¡Se acabó el tiempo!</h1>
            <p>Tu puntuación final fue: <strong>${score}</strong></p>
            <button onclick="window.location.href='mostrar_puntajes.php'">
                Ver puntajes
            </button>
            <br><br>
            <button onclick="location.reload()">Volver a jugar</button>
        `;
    })
    .catch(error => {
        console.error("Error al guardar:", error);
        endGameContainer.innerHTML = `
            <h1>¡Se acabó el tiempo!</h1>
            <p>Tu puntuación final fue: <strong>${score}</strong></p>
            <p style="color:red;">Hubo un error al guardar tu puntaje.</p>
            <button onclick="window.location.href='mostrar_puntajes.php'">
                Ver puntajes
            </button>
            <br><br>
            <button onclick="location.reload()">Volver a jugar</button>
        `;
    });

    const mainContainer = document.querySelector('.main');
    if (mainContainer) {
        mainContainer.remove();
    }
}