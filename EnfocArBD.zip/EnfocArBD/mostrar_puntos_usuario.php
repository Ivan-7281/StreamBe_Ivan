<?php
session_start();
include "db.php";

$usuario_id = $_SESSION['usuario_id'];

$sql = "SELECT SUM(puntaje) AS puntos FROM puntajes WHERE usuario_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

echo json_encode(["puntos" => $row['puntos'] ?? 0]);
?>