<?php
include 'db.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario']);
    $contrasena = $_POST['contrasena'];

    if ($usuario === '' || $contrasena === '') {
        $msg = "Completá todos los campos.";
    } else {
        $hash = password_hash($contrasena, PASSWORD_DEFAULT);

        try {
            $stmt = $conn->prepare("INSERT INTO usuarios (usuario, contrasena) VALUES (?, ?)");
            $stmt->bind_param("ss", $usuario, $hash);
            $stmt->execute();

            echo "<script>
                alert('Registro exitoso. Iniciá sesión.');
                window.location='login.php';
            </script>";
            exit;

        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) {
                $msg = "El usuario ya existe. Probá con otro nombre.";
            } else {
                $msg = "Error inesperado en el registro: " . htmlspecialchars($e->getMessage());
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro - EnfocAr</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
    <div class="encabezado">
        <img src="EnfocAr_logo.png" alt="EnfocAr" class="logo">
    </div>

    <div id="menuPrincipal">
        <div class="submenu">
            <h2>Crear cuenta</h2>

            <?php if ($msg): ?>
                <div class="alerta" style="color: red; margin-bottom: 10px;">
                    <?php echo htmlspecialchars($msg); ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <label>Usuario:</label><br>
                <input type="text" name="usuario" required><br><br>

                <label>Contraseña:</label><br>
                <input type="password" name="contrasena" required><br><br>

                <button class="botones" type="submit">Registrarse</button>
            </form>

            <a href="login.php">¿Ya tenés cuenta? Iniciá sesión</a>
        </div>
    </div>
</body>
</html>