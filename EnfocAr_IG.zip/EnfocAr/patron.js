let dificultad = 3;
let puntos = 0;
let patron = [];
let respuesta = [];
let puedeResponder = false;

const botones = document.querySelectorAll('.patrn');
const estado = document.getElementById('estado');
const puntaje = document.getElementById('Puntaje');

botones.forEach(boton => {
  boton.addEventListener('click', () => {
    if (!puedeResponder) return;
    const valor = parseInt(boton.dataset.num);
    respuesta.push(valor);
    if (respuesta.length === patron.length) {
      verificarRespuesta();
    }
  });
});

function iniciarJuego() {
  patron = [];
  respuesta = [];
  puedeResponder = false;
  estado.textContent = 'Memoriza el patrón...';

  for (let i = 0; i < dificultad; i++) {
    const aux = Math.floor(Math.random() * 6) + 1;
    patron.push(aux);
  }

  mostrarPatron();
}

function mostrarPatron() {
  let i = 0;
  const intervalo = setInterval(() => {
    resaltarBoton(patron[i]);
    i++;
    if (i >= patron.length) {
      clearInterval(intervalo);
      puedeResponder = true;
      estado.textContent = 'Repite el patrón';
    }
  }, 800);
}

function resaltarBoton(num) {
  const boton = document.querySelector(`.patrn[data-num="${num}"]`);
  boton.style.backgroundColor = 'rgb(255, 64, 64)';
  setTimeout(() => {
    boton.style.backgroundColor = 'rgb(255, 255, 255)';
  }, 500);
}

function verificarRespuesta() {
  puedeResponder = false;
  const correcto = respuesta.every((val, i) => val === patron[i]);
  if (correcto) {
    puntos++;
    dificultad++;
    puntaje.textContent = `Puntaje: ${puntos}`;
    setTimeout(iniciarJuego, 2000);
  } else {
    const mainContainer = document.getElementById('contenedor');
    if (mainContainer) {
        mainContainer.remove();
    }

    const endGameContainer = document.getElementById('end-game-container');
    endGameContainer.innerHTML = `
    <h1>Lo lamento, pero ese no era el patrón</h1>
    <h2>Puntaje: ${puntos}</h2>
    <button onclick='location.reload()'>Volver a empezar</button>
  `;
    dificultad = 3;
    puntos = 0;
  }
}
