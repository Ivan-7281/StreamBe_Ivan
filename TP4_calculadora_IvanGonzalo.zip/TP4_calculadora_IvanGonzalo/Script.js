function puedeJubilarse() {
    const edad = parseInt(document.getElementById('edad').value);
    const genero = document.getElementsByClassName('sexo');
    let sexo = null;

    for (let i = 0; i < genero.length; i++) {
        if (genero[i].checked) {
            sexo = genero[i].value;
            break;
        }
    }

    const rta = document.getElementById('respuesta');

    if (sexo == null || isNaN(edad)) {
        rta.innerText = "Completá adecuadamente los campos, por favor.";
        return;
    }

    if ((sexo == "M" && edad >= 65) || (sexo == "F" && edad >= 60)) {
        rta.innerText = "Sí, te podés jubilar. La edad de jubilación es a partir de los 60 en mujeres y a partir de los 65 en hombres.";
    } else {
        rta.innerText = "No, todavía no te podés jubilar.";
    }
}
